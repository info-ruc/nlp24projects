
import pandas as pd
import numpy as np
import os.path as osp
import json
from general_modules.datainit import manage
from general_modules.data_prep.prepare import CommonPrep
from general_modules.data_prep.model_prep import ModelPrep
from general_modules.models.shallow import Models
from dataclasses import dataclass
import argparse
import os

TESTLEN = 12
NEPOCH = 700
USETRUE = True #use true y or scaled y
RMMUL = False #remove multicollinearity or not
D_MODEL = 64
EDPOINT = 500 #when loss < edpoint, stop training


@dataclass
class TransformerConfig:
    feature_num: int
    d_model: int
    nhead: int = 4
    num_layers: int = 1
    seq_length: int = 12
    dropout: float = 0.1
    lr: float = 0.0003

model_name = "transformer"
targetname = "EXP"

# skip to not scale, can only change within ['minmax', 'robust', 'skip']
scaler_map = {
    "dif": "skip",
    "pct": "skip",
    "val": "skip"
}

# process_y means if you want to winsorize target, outlier_bd set the winsorization Q
args = {
    "testlen": TESTLEN,
    "process_y": not USETRUE,
    "outlier_bd": 0.1,
}

# from when you want to slice the data
date_cut_off = "2012-07"

# multicol : (use: bool, disablepca: bool)
# seasonal : (use: bool, method: within ["label", "fourier"], on_y: bool) 
process_setting = {
    "multicol": (False, True),
    "seasonal": (False, 'label', False)
}

# want to use engineered data
use_engineered = False

process_info = pd.read_excel(f"tables/{targetname}/transformation.xlsx")
# target , features will be transformed to real value type (spot) by default, if do not want, set transform = False
target, feature_dict, freq_dict = manage.load_data(target=targetname, engineered=use_engineered)

data_ls = []
for k,v in feature_dict.items():
    if not isinstance(v, pd.DataFrame):
        feature_dict[k] = None
    else:
        data_ls += [v]
feature = pd.concat(data_ls, axis=1)

# for basic transformation
# which features are advance
lag_name_dict = dict(zip(process_info['name'].tolist(),process_info['advance'].tolist()))
# transform to what type for each feature
transform_dict = dict(zip(process_info['name'].tolist(),process_info[model_name].tolist()))

# for scaler
# which scaler to use based on the type of data
scaler_dict = {}

for name, t in transform_dict.items():
    if name in feature.columns:
        scalername = scaler_map[t]
        if scalername not in scaler_dict.keys():
            scaler_dict[scalername] = [name]
        else:
            scaler_dict[scalername] += [name]

args.update(
    {
        "transform_dict": transform_dict,
        "scaler_dict": scaler_dict,
        "lag_name_dict": lag_name_dict,
    }
)

prep = CommonPrep(target=target, feature=feature)
prep.cut_off(st=pd.to_datetime(date_cut_off))

train_tgt, features, target, x_test = prep.process(args=args)
train_tgt = pd.concat([train_tgt, target.loc[train_tgt.index[-1]:, :]], axis=0)
train_tgt = train_tgt[~train_tgt.index.duplicated(keep='first')]
if isinstance(x_test, pd.DataFrame):
    features = pd.concat([features, x_test], axis=0)

if RMMUL:
    from general_modules.data_prep.model_prep import ModelPrep
    preparer = ModelPrep()
    features,_ = preparer.rm_multicollinearity(X_train=features, X_test=None, disable_pca=True)

def add_seasonal(df:pd.DataFrame):
    df['sin_month'] = np.sin(2*np.pi*(df.index.month - 1) / 12)
    df['cos_month'] = np.cos(2*np.pi*(df.index.month - 1) / 12)
    
def get_valid_data(df:pd.DataFrame):
    first_valid_indexes = [df[col].first_valid_index() for col in df.columns]
    first_valid_indexes.sort()
    first_valid_index = first_valid_indexes[-1]
    valid_df = df.loc[first_valid_index:, :]
    
    return valid_df

def scale_larger(df:pd.DataFrame):
    for col in df.columns[1:]:
        while abs(df[col][:-TESTLEN]).mean() < 10:
            df.loc[:,col] *= 10
            
def scale_smaller(df:pd.DataFrame):
    for col in df.columns[1:]:
        while abs(df[col][:-TESTLEN]).mean() > 100:
            df.loc[:,col] /= 10

df = pd.concat([train_tgt, features], axis=1)
add_seasonal(df)
df = get_valid_data(df)
df.ffill()
scale_larger(df)
scale_smaller(df)

import torch
import torch.nn as nn 
import torch.optim as optim
from dataclasses import dataclass
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import math

class TransDataset(Dataset):
    def __init__(self, data, seq_len, test_len):
        super().__init__()
        
        if isinstance(data, pd.DataFrame):
            data = data.to_numpy()
        
        self.data = torch.tensor(data, dtype=torch.float32)
        self.seq_len = seq_len
        self.num_samples = len(data) - seq_len - test_len + 1 - 1
        self.test_len = test_len
        
        self.testmode = 0
    
    def test(self):
        self.testmode = 1
    
    def train(self):
        self.testmode = 0
    
    def __len__(self):
        if self.testmode:
            return self.test_len
        else:
            return self.num_samples
        
    def __getitem__(self, index):
        if self.testmode:
            st = self.num_samples
            x = self.data[st + index +1 : st + index+1 + self.seq_len, 1:]
            y = self.data[st + index: st + index + self.seq_len, 0]
            z = self.data[st + index + self.seq_len, 0]
        else:
            x = self.data[index+1:index+1 + self.seq_len, 1:]
            y = self.data[index:index + self.seq_len, 0]
            z = self.data[index + self.seq_len, 0]
        return x,y,z

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))

        pe[:, 0::2] = torch.sin(position * div_term)  
        pe[:, 1::2] = torch.cos(position * div_term)  
        
        self.register_buffer('pe', pe.unsqueeze(0))  

    def forward(self, x):
        return x + self.pe[:, :x.size(1)] 

class TEncoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        
        self.transform = nn.Linear(config.feature_num, config.d_model)
        self.context_transform = nn.Linear(config.feature_num, config.d_model)  # New layer for contextual input
        self.pos_encoder = PositionalEncoding(d_model=config.d_model)
        self.encoderlayer = nn.TransformerEncoderLayer(d_model=config.d_model, nhead=config.nhead, dropout=config.dropout, batch_first=True, bias=True)
        self.encoder = nn.TransformerEncoder(encoder_layer=self.encoderlayer, num_layers=config.num_layers)
        self.combine = nn.Linear(config.seq_length, 1)
        self.fc_out = nn.Linear(config.d_model, 1)
        self.init_weights()

    def init_weights(self):
        def init_layer(layer):
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight)
                if layer.bias is not None:
                    nn.init.zeros_(layer.bias)
            elif isinstance(layer, nn.TransformerEncoderLayer):
                for param in layer.parameters():
                    if param.dim() > 1:
                        nn.init.xavier_uniform_(param)
        self.apply(init_layer)
    
    def forward(self, input, context=None):
        input = self.transform(input)
        if context is not None:
            context = self.context_transform(context)
            input += context  # Integrate contextual input
        input += self.pos_encoder(input)
        output = self.encoder(input)
        output = output.squeeze(0).contiguous().transpose(0,1)
        output = self.combine(output).squeeze(1)
        output = self.fc_out(output)
        
        return output


def train(model, criterion, optimizer, dataloader, device, num_epochs):
    loss_ls = []
    for epoch in range(num_epochs):
        model.train()
        epoch_loss = 0.0
        for features, target_lag, target in dataloader:
            # Move data to CUDA
            features, target_lag, target = features.to(device), target_lag.to(device), target.to(device)
            
            optimizer.zero_grad()
            # Forward pass
            if isinstance(model, TEncoder):
                output = model(features)
            else:
                pass
            loss = criterion(output, target)
            
            # Backward pass
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss.item()
        
        avg_loss = epoch_loss / len(dataloader)
        loss_ls += [avg_loss]
        print(f"Epoch {epoch+1}, Loss: {avg_loss:.4f}")
        if len(loss_ls) > 20:
            if np.mean(loss_ls[-20:]) < EDPOINT:
                break
    return loss_ls

# Check if CUDA is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Define configuration using dataclass
f_num = df.shape[1] - 1
j = 8
dimension = 0
while 1:
    if j < f_num:
        j*=2
    else:
        dimension = j
        break

config = TransformerConfig(feature_num=f_num, d_model=D_MODEL if D_MODEL else dimension)

# Instantiate model with configuration and move it to GPU
# model = TransformerTimeSeries(config).to(device)
model = TEncoder(config).to(device)
# Loss and optimizer
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=config.lr)

# Create the DataLoader
dataloader = DataLoader(TransDataset(data=df, seq_len=12, test_len=12), batch_size=1)
loss_ls = train(model,criterion,optimizer,dataloader,device=device, num_epochs=NEPOCH)

def evaluate(model, dataloader, device='cpu'):

    model.eval() 
    y_true = []
    y_pred = []

    with torch.no_grad(): 
        for ft, tg_lag, tg in dataloader:
            ft, tg_lag, tg = ft.to(device), tg_lag.to(device), tg.to(device) 
            
            output = model(ft) 
            
            y_true.append(tg.cpu().numpy()[0]) 
            try:
                y_pred.append(output.cpu().numpy()[0])
            except:
                y_pred.append(np.array(output))

    return y_pred

dataset = TransDataset(data=df, seq_len=12, test_len=12)
model = model.to('cpu')
dataset.train()
train_loader = DataLoader(dataset)
y_fitted = evaluate(model=model, dataloader=train_loader)
dataset.test()
test_loader = DataLoader(dataset)
y_pred = evaluate(model=model, dataloader=test_loader)

index_fitted = df.index[-len(y_pred)-len(y_fitted):-len(y_pred)]
index_pred = df.index[-len(y_pred):]

fit = pd.Series(data=y_fitted,index=index_fitted, name="y_fitted")
pred = pd.Series(data=y_pred,index=index_pred, name="y_predicted")
true = pd.Series(data=target[target.columns[0]].values, index=target.index, name="y_true")
src = pd.concat([fit,pred,true],axis=1)
src = src.loc[src['y_fitted'].first_valid_index():,]

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output_path', type=str, required=True, help='Path to store evaluation results.')
    parser.add_argument('--iter', type=str, required=True, help='Which iter.')
    return parser.parse_args()

args = parse_args()
os.mkdir(f"{args.output_path}/{args.iter}")
src.to_csv(f"{args.output_path}/{args.iter}/src.csv")

torch.save(model.state_dict(), f"{args.output_path}/{args.iter}/model.pth")


