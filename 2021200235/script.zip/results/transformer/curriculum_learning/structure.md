### Embedding

* Input:

1. Token matrix: B* T (Batch size* Sentence length)
2. Position vector: T (Sentence length)

* Output:

1. wte:
   Token matrix --nn.Embedding(vocabulary, n_embd)--> B* T* C
2. wpe:
   Position vector --nn.Embedding(blocksize, n_embd)--> T* C

    RETURN wte+wpe

### Attention

* Input:

    x=wte+wpe: B* T* C

* Output:

1. x --nn.Linear(n_embd, 3*n_embd)--> B *T *3C
2. q, k, v:

    B *T *3C --.split(n_embd, dim=2)--> B *T *C

    B *T *C --.view(B, T, heads, C // heads)--> B *T *H *S --.transpose(1,2)--> B *H *T *S

    RETURN (attension_matrix, q, k, v)

### Normalization

* Input:

    x: anyshape (X*Y *Z *... *M)

* Output

    RETURN F.layernorm(x, designed_dimension, designed_weight)

### FeedForward

* Input:

    x: B* T* C

* Output:

1. x --nn.Linear(C, 4C)--> B *T *4C
2. B *T *4C --nn.GELU()--> B *T *4C
3. B *T *4C --nn.Linear(4C, C)--> B *T *C

   RETURN B* T* C

### Encoder

* Input:

    x: B* T* C

* Output:

1. x --Attention--> (attension_matrix, q, k, v)
2. attension_matrix + x --Normalization--> Z: B *T *C
3. Z --FeedForward--> Z_new
4. Z + Z_new --Normalization--> RES
   RETURN (RES, k, v)

### Decoder

* Input:

1. x: B *T *C
2. k, v: B *H *T *S

* Output:

1. x --Attention--> (attension_matrix, q, k1, v1)
2. attention_matrix + x --Normalization--> Z: B* T* C
3. q, k, v --Attention_new--> attension_matrix_new
4. attention_matrix_new + Z --Normalization--> M: B* T* C
5. M --FeedForward--> M_new
6. M + M_new --Normalization--> RES
   RETURN RES

### Pred

* Input:

    x: B* T* C

* Output:

1. x --nn.Linear(C, C)--> z: B* T* C
2. z --F.softmax(dim=-1)--> RES
   RETURN RES #the last dimension of RES now is the possibility
