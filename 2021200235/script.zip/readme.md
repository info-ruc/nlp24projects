该项目为复现类似AI Scientist的自动想法生成、实验和分析功能
目前完成了想法生成、查新、自动实验、简单分析

在API_KEYS中填入openai api的key

然后在LLM路径下，顺次运行：（terminal出现redo询问输入1）
genideas.py，ideanovel.py，doidea.py

可以得到结果，存储在results文件夹下对应ideaname的子文件夹下：
run_x.py为第x次迭代的代码文件，run_x文件夹下存储对应文件的实验结果，notes存储几次的结果和分析

结果中，macro_pred有效完成整个流程，transformer为测试summarization task，因为算力和平台不能翻墙等原因，自动实验阶段仅在dynamic_batch_size下有一轮的结果在res子文件夹下
