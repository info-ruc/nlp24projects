# %%
from aider.coders import Coder
from aider.models import Model
from aider.io import InputOutput
import json
import shutil
import os.path as osp
import subprocess
from subprocess import TimeoutExpired
import sys
import os

# %%
TIMEOUT = 7200

coder_prompt = """Your goal is to implement the following idea: {title}.
The proposed experiment is as follows: {idea}.
You are given a total of up to {max_runs} runs to complete the necessary experiments. You do not need to use all {max_runs}.

First, plan the list of experiments you would like to run. For example, if you are sweeping over a specific hyperparameter, plan each value you would like to test for each run.

Note that we already provide the baseline results, so you do not need to re-run it.

For reference, the baseline results are as follows:

{baseline_results}

After you complete each change, we will run the command `python experiment.py --output_path=path --filename=run_i.txt' where i is the run number and evaluate the results.
YOUR PROPOSED CHANGE MUST USE THIS COMMAND FORMAT, DO NOT ADD ADDITIONAL COMMAND LINE ARGS.
You can then implement the next thing on your list."""

# %%
def run_experiment(
    folder_name,
    run,
    timeout = TIMEOUT,
):
    path = "F:/NLP/results/macro_pred"
    shutil.copy(
        osp.join(folder_name, "experiment.py"),
        osp.join(folder_name, f"run_{run}.py"),
    )
    
    shutil.copy(
        osp.join(folder_name, "experiment.py"),
        osp.join("results/macro_pred", "experiment.py"),
    )
    
    shutil.copy(
        osp.join(folder_name, "eval.py"),
        osp.join("results/macro_pred", "eval.py"),
    )
    
    commands = [
        "python",
        "experiment.py",
        f"--output_path={osp.abspath(folder_name)}",
        f"--iter=run_{run}"
    ]
    
    commands_2 = [
        "python",
        "eval.py",
        f"--output_path={osp.abspath(folder_name)}/run_{run}",
    ]
    try:
        result = subprocess.run(
            commands, cwd=path, stderr=subprocess.PIPE, text=True, timeout=timeout
        )
        
        subprocess.run(
            commands_2, cwd=path, stderr=subprocess.PIPE, text=True, timeout=timeout
        )
        
        if result.stderr:
            print(result.stderr, file=sys.stderr)
            return 1, f"your code has something wrong: {result.stderr}"
            
        if result.returncode != 0:
            print(f"Failed running experiment run{run}")
        else:
            with open(osp.join(folder_name, f"run_{run}", "result.txt"), "r") as fp:
                results = fp.read()
        
        new_prompt = f"""Run {run} completed. Here are the results:
{results}

Decide if you need to re-plan your experiments given the result (you often will not need to).

Someone else will be using `notes.txt` to perform a writeup on this in the future.
Please include *all* relevant information for the writeup on Run {run}, including an experiment description and the run number. Be as verbose as necessary.

Then, implement the next thing on your list.
We will then run the command `python experiment.py --output_path={path} --filename=run_{run + 1}'.
YOUR PROPOSED CHANGE MUST USE THIS COMMAND FORMAT, DO NOT ADD ADDITIONAL COMMAND LINE ARGS.
If you are finished with experiments, respond with 'ALL_COMPLETED'."""

        return result.returncode, new_prompt
    except TimeoutExpired:
        print(f"Run {run} timed out (limitation={TIMEOUT}s)")
        if osp.exists(osp.join(path, f"run_{run}")):
            shutil.rmtree(osp.join(path, f"run_{run}"))
        new_prompt = f"Run timed out (limitation={TIMEOUT} seconds)"
        return 1, new_prompt
        

# %%
def perform_experiments(
    idea,
    folder_name,
    coder,
    base_res,
    exp_iters,
):
    use_prompt = coder_prompt.format(
        title = idea['Title'],
        idea = idea['Experiment'],
        max_runs = exp_iters,
        baseline_results = base_res,
    )
    max_try = 5
    cnt = 0
    for i in range(exp_iters):
        print(f"run {i+1}...")

        while 1:
            coder_out = coder.run(use_prompt)
            if "ALL_COMPLETED" in coder_out:
                cnt = 99
                break
            
            print(f"code edited according to idea, try running: iter{i+1}: {cnt} times")
            return_code, use_prompt = run_experiment(folder_name, i+1)
            if return_code == 0:
                cnt = 0
                break
            else:
                cnt += 1
            if cnt >= max_try:
                print(f"Experiment Failed in run {i+1}")
                return False
        if cnt == 99:
            break
    summary_prompt = """ 
Please modify `notes.txt` with a sumarization and analysis of the former runs of this idea one by one.
Please do so indepth, this sumarizations and analyses will be used as foundation of report.
"""
    coder.run(summary_prompt)
    
    return True

# %%
def do_ideas(
    base_dir,
    result_dir,
    idea,
    model,
    exp_iters,
):
    idea_name = idea['Name']
    destination = folder_name = osp.join(result_dir, idea_name)
    if not osp.exists(folder_name):
        pass
    else:
        redo = input("Redo the idea? it already exists. if not, input 0; if yes, input any else.")
        if redo:
            shutil.rmtree(folder_name)     
        else:
            exit(1)
    
    # initialize result folder
    shutil.copytree(base_dir, destination, dirs_exist_ok=True)
    with open(osp.join(base_dir, "base.json"), "r") as fp:
        base_res = json.load(fp)
    exp_f = osp.join(folder_name, "experiment.py")
    note_f = osp.join(folder_name, "notes.txt")
    with open(note_f, "w") as fp:
        fp.write(f"# Title: {idea['Title']}\n")
        fp.write(f"# Experiment description: {idea['Experiment']}\n")
        fp.write(f"## Run 0: Baseline\n")
        fp.write(f"Results: {base_res}\n")
        fp.write(f"Description: Baseline results.\n")
    
    # start experiment
    try:
        print(f"Doing idea: {idea_name}")
        fnames = [exp_f, note_f]
        io = InputOutput(
            yes=True, chat_history_file=f"{folder_name}/{idea_name}_aider.txt"
        )
        main_model = Model(model=model)
        coder = Coder.create(
            main_model=main_model,
            fnames=fnames,
            io=io,
            stream=False,
            use_git=False,
            edit_format="diff",
        )
        
        print("aider ready, start experiment")
        
        try:
            result = perform_experiments(idea, folder_name, coder, base_res, exp_iters)
        except Exception as e:
            print(f"Failed to do idea: {idea_name}\n{e}")
            return False
        
        if not result:
            print(f"Failed to do idea: {idea_name}")
            return False
        
        print("Experiment succeeds")
    
    except Exception as e:
        print(f"Failed to do idea: {idea_name}")

# %%
with open("F:/NLP/templates/macro_pred/ideas.json", "r") as fp:
    ideas = json.load(fp=fp)
    
import os
with open("F:/NLP/API_KEYS/OPENAI.txt", "r") as fp:
    api_key = fp.read()
os.environ["OPENAI_API_KEY"] = api_key

do_ideas(
    base_dir="F:/NLP/templates/macro_pred",
    result_dir="F:/NLP/results/macro_pred",
    idea=ideas[-2],
    model="gpt-4o",
    exp_iters=3,
)


