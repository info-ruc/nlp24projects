import json

def get_response_from_llm(
    msg,
    client,
    model,
    system_message,
    need_sys=True,
    msg_history=None,
    temperature=0.75,
):
    if msg_history is None:
        msg_history = []
        
    new_msg_history = msg_history + [{"role": "user", "content": msg}]
    response = client.chat.completions.create(
        model = model,
        messages = [
            {"role": "system", "content": system_message},
            *new_msg_history,
        ] if need_sys else [
            *new_msg_history,
        ],
        temperature = temperature,
        max_tokens = 3000,
        n = 1,
        stop = None,
        seed = 0,
    )
    content = response.choices[0].message.content
    new_msg_history = new_msg_history + [{"role": "assistant", "content": content}]
    
    return content, new_msg_history

def extract_json(llm_output):
    json_start_marker = "```json"
    json_end_marker = "```"

    # find the start and end indices of the JSON string
    start_index = llm_output.find(json_start_marker)
    if start_index != -1:
        start_index += len(json_start_marker)  # move past the marker
        end_index = llm_output.find(json_end_marker, start_index)
    else:
        return None  # JSON markers not found

    if end_index == -1:
        return None  # End marker not found

    # extract json str
    json_string = llm_output[start_index:end_index].strip()
    try:
        parsed_json = json.loads(json_string)
        return parsed_json
    except json.JSONDecodeError:
        return None  # invalid JSON format