# %%
import json
import os.path as osp
from llm import get_response_from_llm, extract_json

# %%
code_ = """
{description}
<exp.py>
{code}
<exp.py>

{prompt}

"""

idea_prompt = """

Ideas you have already generated:

'''
{prev_ideas}
'''

Come up with the next impactful and creative idea for research experiments and directions you can feasibly investigate with the code provided.
Note that you will not have access to any additional resources or datasets.
Make sure any idea is not overfit the specific training dataset or model, and has wider significance.

Respond in the following format:

THOUGHT:
<THOUGHT>

NEW IDEA JSON:
```json
<JSON>
```

In <THOUGHT>, first briefly discuss your intuitions and motivations for the idea. Detail your high-level plan, necessary design choices and ideal outcomes of the experiments. Justify how the idea is different from the existing ones.

In <JSON>, provide the new idea in JSON format with the following fields:
- "Name": A shortened descriptor of the idea. Lowercase, no spaces, underscores allowed.
- "Title": A title for the idea, will be used for the report writing.
- "Experiment": An outline of the implementation. E.g. which functions need to be added or modified, how results will be obtained, ...
- "Interestingness": A rating from 1 to 10 (lowest to highest).
- "Feasibility": A rating from 1 to 10 (lowest to highest).
- "Novelty": A rating from 1 to 10 (lowest to highest).

Be cautious and realistic on your ratings.
This JSON will be automatically parsed, so ensure the format is precise.
You will have {num_reflections} rounds to iterate on the idea, but do not need to use them all.
"""


# %%
def genideas(
    num_ideas,
    template_dir,
    num_reflections,
    client,
    model,
    already_gen = False,
):
    if already_gen:
        pass
    
    ideas = []
    with open(osp.join(template_dir, "seed_ideas.json"), "r") as fp:
        seed_ideas = json.load(fp)
    for idea in seed_ideas:
        ideas.append(json.dumps(idea))
        
    with open(osp.join(template_dir, "experiment.py"), "r") as fp:
        code = fp.read()
        
    with open(osp.join(template_dir, "prompt.json"), "r") as fp:
        prompt = json.load(fp)
        
    idea_sys_prompt = prompt['system']
    
    for _ in range(num_ideas):
        print(f"Generating {_+1} / {num_ideas} idea")
        try:
            prev_ideas = "\n\n".join(ideas)

            msg_history = []
            print(f"Iteration 1/{num_reflections}")
            response, msg_history = get_response_from_llm(
                msg = code_.format(
                        description = prompt['description'],
                        code = code,
                        prompt = idea_prompt.format(
                            prev_ideas = prev_ideas,
                            num_reflections = num_reflections,
                        )
                ) if _ == 0 else idea_prompt.format(
                        prev_ideas = prev_ideas,
                        num_reflections = num_reflections,
                ),
                client = client,
                model = model,
                system_message = idea_sys_prompt,
                need_sys=True if _ == 0 else False,
                msg_history = msg_history,
            )
            
            # here's the idea
            output = extract_json(response)
            assert output is not None
            print(output)
            
            if num_reflections > 1:
                pass
            
            ideas.append(json.dumps(output))
        
        except Exception as exception:
            print(f"Failed to gen idea: {exception}")
            continue
    
    idea_ls = []
    for idea in ideas:
        idea_ls.append(json.loads(idea))
        
    with open(osp.join(template_dir, "ideas.json"), "w") as fp:
        json.dump(idea_ls, fp, indent=4)
        
    return idea_ls

# %%
# testing if works
import openai
client_model = 'gpt-4o'
with open("F:/NLP/API_KEYS/OPENAI.txt", "r") as fp:
    api_key = fp.read()

client = openai.OpenAI(api_key=api_key)

base_dir = osp.join("F:/NLP/templates", "macro_pred")
ideas = genideas(
    template_dir=base_dir,
    num_ideas=5,
    num_reflections=1,
    client=client,
    model=client_model,
    already_gen=False,
)


