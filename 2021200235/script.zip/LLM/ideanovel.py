# %%
import os.path as osp
from bs4 import BeautifulSoup
from typing import List, Dict, Union
import requests
import backoff
from llm import get_response_from_llm, extract_json
import json

# %%
novelty_system = """You are an ambitious AI PhD student who is looking to publish a paper that will contribute significantly to the field.
You have an idea and you want to check if it is novel or not. I.e., not overlapping significantly with existing literature or already well explored.
Be a harsh critic for novelty, ensure there is a sufficient contribution in the idea for a new conference or workshop paper.
You will be given access to the Semantic Scholar API, which you may use to survey the literature and find relevant papers to help you make your decision.
The top 10 results for any search query will be presented to you with the abstracts.

You will be given {num_rounds} to decide on the paper, but you do not need to use them all.
At any round, you may exit early and decide on the novelty of the idea.
Decide a paper idea is novel if after sufficient searching, you have not found a paper that significantly overlaps with your idea.
Decide a paper idea is not novel, if you have found a paper that significantly overlaps with your idea.

{description}
<experiment.py>
{code}
</experiment.py>
"""

novelty_prompt = '''
Round {current_round}/{num_rounds}.
You have this idea:

"""
{idea}
"""

The results of the former queries are (empty on first round):
"""
{last_query_results}
"""

Respond in the following format:

THOUGHT:
<THOUGHT>

RESPONSE:
```json
<JSON>
```

In <THOUGHT>, first briefly reason over the idea and identify any query that could help you make your decision.
If you have made your decision, add "Decision made: novel." or "Decision made: not novel." to your thoughts.

ONLY when you made your decision, In <JSON>, respond in JSON format with ONLY the following field:
- "Reference": A list of reference in apa format, you can look for results of former queries to get it, if there's nothing, set it to "NAN". You can go through the references to choose you think most representative ones.

ELSE, In <JSON>, respond in JSON format with ONLY the following field:
- "Query": An optional search query to search the literature (e.g. attention is all you need). You must make a query if you have not decided this round.

A query will work best if you are able to recall the exact name of the paper you are looking for, or the authors.
This JSON will be automatically parsed, so ensure the format is precise.
'''

# %%
def extract_xml(
    to_extract
):
    soup = BeautifulSoup(to_extract, 'lxml-xml')
    entries = soup.find_all('entry')
    
    papers = []
    
    for entry in entries:
        title = entry.title.text
        authors = entry.find_all('author')
        author_names = [author.find('name').text for author in authors]
        summary = entry.summary.text.strip()
        link = entry.id.text

        published_date = entry.published.text
        apa_reference = f"{', '.join(author_names)}. ({published_date[:4]}). {title}. {link}"

        papers.append({
            "title": title,
            "author": ', '.join(author_names),
            "summary": summary,
            "APA reference format": apa_reference
        })
    
    return papers

# %%
def search_papers(
    query,
    api="arxiv",
    result_limit=10,
):
    if not query:
        return None
    
    if api=="arxiv":
        url = "http://export.arxiv.org/api/query"
        params = {
            "search_query": query,
            "start": 0,
            "max_results": result_limit,
        }
        xml_response = requests.get(url=url, params=params).text
        papers = extract_xml(xml_response)
        
    return papers
        

# %%
def check_novelty(
    ideas,
    template_dir,
    client,
    model,
    max_iter=3,
    recheck=False,
):
    with open(osp.join(template_dir, "experiment.py"), "r") as fp:
        code = fp.read()
    with open(osp.join(template_dir, "prompt.json"), "r") as fp:
        prompt = json.load(fp)
        task_description = prompt["description"]
    
    checked_ideas = []
    
    for i, idea in enumerate(ideas):
        if not recheck:
            if "ISNOVEL" in idea:
                print(f"Idea {i} passed.")
                continue
        
        novel = False
        msg_history = []
        papers = {}
        references = ""
        
        for j in range(max_iter):
            try:
                response, msg_history = get_response_from_llm(
                    msg=novelty_prompt.format(
                        current_round = j+1,
                        num_rounds = max_iter,
                        idea = str(idea),
                        last_query_results = str(papers),
                    ),
                    client=client,
                    model=model,
                    system_message=novelty_system.format(
                        num_rounds=max_iter,
                        description=task_description,
                        code=code,
                    ),
                    need_sys=True if j == 0 else False,
                    msg_history=msg_history,
                )
                
                if "decision made: novel" in response.lower():
                    print("Decision made: novel after round", j)
                    novel = True
                    json_output = extract_json(response)
                    assert json_output is not None, "Invalid format or lack JSON part in response"
                    references = json_output["Reference"]
                    break
                if "decision made: not novel" in response.lower():
                    print("Decision made: not novel after round", j)
                    json_output = extract_json(response)
                    assert json_output is not None, "Invalid format or lack JSON part in response"
                    references = json_output["Reference"]
                    break
                
                # json which include paper infos
                json_output = extract_json(response)
                assert json_output is not None, "Invalid format or lack JSON part in response"
                query = json_output["Query"]
                papers_ls = search_papers(query, result_limit=10)
                if papers_ls is None:
                    papers[f"Iter{j}"] = "Papers not found."
                else:
                    papers[f"Iter{j}"] = str(papers_ls)
            except Exception as exception:
                print(f"Failed to check novelty: {exception}")
                continue
            
        idea["ISNOVEL"] = novel
        idea["Reference"] = references
        checked_ideas.append(idea)
        
    with open(osp.join(template_dir, "ideas.json"), "w") as fp:
        json.dump(checked_ideas, fp=fp, indent=4)
        
    return checked_ideas

# %%
if __name__ == "__main__":
    template_dir = osp.join("F:/NLP/templates", "macro_pred")
    with open(osp.join(template_dir, "ideas.json"), "r") as fp:
        ideas = json.load(fp)
        
    # testing if works
    import openai
    client_model = 'gpt-4o'
    with open("F:/NLP/API_KEYS/OPENAI.txt", "r") as fp:
        api_key = fp.read()

    client = openai.OpenAI(api_key=api_key)

    checked_ideas = check_novelty(
        ideas = ideas,
        template_dir=template_dir,
        client=client,
        model=client_model,
        max_iter=10,
        recheck=True,
    )


